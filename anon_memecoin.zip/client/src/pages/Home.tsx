import { Button } from "@/components/ui/button";
import { APP_LOGO, APP_TITLE } from "@/const";
import { ExternalLink, Copy, Check } from "lucide-react";
import { useState } from "react";

export default function Home() {
  const [copied, setCopied] = useState(false);
  const contractAddress = "GDEr3iizg4uhfspEz46zahhrE1w74CoQh8gxLAMepump";

  const copyToClipboard = () => {
    navigator.clipboard.writeText(contractAddress);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-black/80 backdrop-blur-md z-50 border-b border-purple-500/20">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={APP_LOGO} alt="ANON" className="w-10 h-10 rounded-lg" />
            <span className="text-xl font-bold text-purple-400">$ANON</span>
          </div>
          <div className="hidden md:flex gap-8">
            <a href="#about" className="hover:text-purple-400 transition">About</a>
            <a href="#how-to-buy" className="hover:text-purple-400 transition">How to Buy</a>
            <a href="#tokenomics" className="hover:text-purple-400 transition">Tokenomics</a>
            <a href="#roadmap" className="hover:text-purple-400 transition">Roadmap</a>
            <a href="#community" className="hover:text-purple-400 transition">Community</a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-purple-900/20 to-transparent opacity-50"></div>
        <div className="max-w-6xl mx-auto relative z-10">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
                Stay <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600">Anonymous</span>
              </h1>
              <p className="text-xl text-gray-300 mb-8">
                The memecoin that values privacy, community, and decentralization. Join the revolution.
              </p>
              <div className="flex gap-4">
                <Button 
                  size="lg"
                  className="bg-purple-600 hover:bg-purple-700 text-white"
                  onClick={() => window.open("https://pump.fun/coin/" + contractAddress, "_blank")}
                >
                  Buy on Pump.fun <ExternalLink className="ml-2 w-4 h-4" />
                </Button>
                <Button 
                  size="lg"
                  variant="outline"
                  className="border-purple-500 text-purple-400 hover:bg-purple-900/20"
                  onClick={() => window.open("https://solscan.io/token/" + contractAddress, "_blank")}
                >
                  View on Solscan
                </Button>
              </div>
            </div>
            <div className="flex justify-center">
              <div className="relative w-64 h-64">
                <img 
                  src={APP_LOGO} 
                  alt="Anonymous Logo" 
                  className="w-full h-full object-contain drop-shadow-2xl"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-full blur-3xl"></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4 bg-gradient-to-b from-black to-purple-900/10">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold mb-12 text-center">About $ANON</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-purple-900/20 border border-purple-500/30 rounded-lg p-8 hover:border-purple-500/60 transition">
              <div className="text-3xl mb-4">🔐</div>
              <h3 className="text-xl font-bold mb-4">Privacy First</h3>
              <p className="text-gray-300">
                Built on the principles of anonymity and privacy. Your identity remains yours.
              </p>
            </div>
            <div className="bg-purple-900/20 border border-purple-500/30 rounded-lg p-8 hover:border-purple-500/60 transition">
              <div className="text-3xl mb-4">👥</div>
              <h3 className="text-xl font-bold mb-4">Community Driven</h3>
              <p className="text-gray-300">
                Powered by a passionate community of believers in decentralization and freedom.
              </p>
            </div>
            <div className="bg-purple-900/20 border border-purple-500/30 rounded-lg p-8 hover:border-purple-500/60 transition">
              <div className="text-3xl mb-4">⚡</div>
              <h3 className="text-xl font-bold mb-4">Solana Speed</h3>
              <p className="text-gray-300">
                Lightning-fast transactions on the Solana blockchain with minimal fees.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How to Buy Section */}
      <section id="how-to-buy" className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold mb-12 text-center">How to Buy $ANON</h2>
          <div className="grid md:grid-cols-4 gap-6 mb-12">
            <div className="text-center">
              <div className="bg-purple-600 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">1</div>
              <h3 className="font-bold mb-2">Get a Wallet</h3>
              <p className="text-gray-400 text-sm">Create a Solana wallet (Phantom, Magic Eden, etc.)</p>
            </div>
            <div className="text-center">
              <div className="bg-purple-600 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">2</div>
              <h3 className="font-bold mb-2">Get SOL</h3>
              <p className="text-gray-400 text-sm">Fund your wallet with Solana (SOL)</p>
            </div>
            <div className="text-center">
              <div className="bg-purple-600 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">3</div>
              <h3 className="font-bold mb-2">Visit Pump.fun</h3>
              <p className="text-gray-400 text-sm">Go to Pump.fun and search for $ANON</p>
            </div>
            <div className="text-center">
              <div className="bg-purple-600 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">4</div>
              <h3 className="font-bold mb-2">Swap & Hold</h3>
              <p className="text-gray-400 text-sm">Swap SOL for $ANON and join the community</p>
            </div>
          </div>

          <div className="bg-purple-900/20 border border-purple-500/30 rounded-lg p-8">
            <h3 className="text-xl font-bold mb-4">Contract Address</h3>
            <div className="flex items-center gap-2 bg-black/50 p-4 rounded-lg">
              <code className="flex-1 text-sm text-purple-300 break-all">{contractAddress}</code>
              <button
                onClick={copyToClipboard}
                className="p-2 hover:bg-purple-600/20 rounded transition"
              >
                {copied ? <Check className="w-5 h-5 text-green-400" /> : <Copy className="w-5 h-5 text-gray-400" />}
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Tokenomics Section */}
      <section id="tokenomics" className="py-20 px-4 bg-gradient-to-b from-black to-purple-900/10">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold mb-12 text-center">Tokenomics</h2>
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-bold mb-6">Token Details</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center border-b border-purple-500/20 pb-3">
                  <span className="text-gray-300">Total Supply</span>
                  <span className="font-bold text-purple-400">1,000,000,000 $ANON</span>
                </div>
                <div className="flex justify-between items-center border-b border-purple-500/20 pb-3">
                  <span className="text-gray-300">Decimals</span>
                  <span className="font-bold text-purple-400">6</span>
                </div>
                <div className="flex justify-between items-center border-b border-purple-500/20 pb-3">
                  <span className="text-gray-300">Network</span>
                  <span className="font-bold text-purple-400">Solana</span>
                </div>
                <div className="flex justify-between items-center border-b border-purple-500/20 pb-3">
                  <span className="text-gray-300">Launch Type</span>
                  <span className="font-bold text-purple-400">Fair Launch</span>
                </div>
              </div>
            </div>
            <div>
              <h3 className="text-2xl font-bold mb-6">Distribution</h3>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-300">Community</span>
                    <span className="font-bold text-purple-400">70%</span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div className="bg-purple-600 h-2 rounded-full" style={{width: "70%"}}></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-300">Liquidity</span>
                    <span className="font-bold text-purple-400">20%</span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div className="bg-purple-600 h-2 rounded-full" style={{width: "20%"}}></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-300">Development</span>
                    <span className="font-bold text-purple-400">10%</span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div className="bg-purple-600 h-2 rounded-full" style={{width: "10%"}}></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Roadmap Section */}
      <section id="roadmap" className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold mb-12 text-center">Roadmap</h2>
          <div className="space-y-8">
            <div className="flex gap-6">
              <div className="flex flex-col items-center">
                <div className="w-4 h-4 bg-purple-600 rounded-full"></div>
                <div className="w-1 h-20 bg-purple-600/30"></div>
              </div>
              <div className="pb-8">
                <h3 className="text-xl font-bold text-purple-400 mb-2">Phase 1: Launch</h3>
                <p className="text-gray-300">Fair launch on Pump.fun with community-driven marketing</p>
              </div>
            </div>
            <div className="flex gap-6">
              <div className="flex flex-col items-center">
                <div className="w-4 h-4 bg-purple-600 rounded-full"></div>
                <div className="w-1 h-20 bg-purple-600/30"></div>
              </div>
              <div className="pb-8">
                <h3 className="text-xl font-bold text-purple-400 mb-2">Phase 2: Community Growth</h3>
                <p className="text-gray-300">Build Discord community, establish social presence, grow holder base</p>
              </div>
            </div>
            <div className="flex gap-6">
              <div className="flex flex-col items-center">
                <div className="w-4 h-4 bg-purple-600 rounded-full"></div>
                <div className="w-1 h-20 bg-purple-600/30"></div>
              </div>
              <div className="pb-8">
                <h3 className="text-xl font-bold text-purple-400 mb-2">Phase 3: Partnerships</h3>
                <p className="text-gray-300">Strategic partnerships with other projects and platforms</p>
              </div>
            </div>
            <div className="flex gap-6">
              <div className="flex flex-col items-center">
                <div className="w-4 h-4 bg-purple-600 rounded-full"></div>
              </div>
              <div>
                <h3 className="text-xl font-bold text-purple-400 mb-2">Phase 4: Future</h3>
                <p className="text-gray-300">Expand ecosystem, explore new opportunities, stay anonymous</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Community Section */}
      <section id="community" className="py-20 px-4 bg-gradient-to-b from-black to-purple-900/10">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold mb-12 text-center">Join the Community</h2>
          <div className="grid md:grid-cols-4 gap-6">
            <a href="#" className="bg-purple-900/20 border border-purple-500/30 rounded-lg p-6 hover:border-purple-500/60 transition text-center">
              <div className="text-4xl mb-4">💬</div>
              <h3 className="font-bold mb-2">Discord</h3>
              <p className="text-gray-400 text-sm">Join our community</p>
            </a>
            <a href="#" className="bg-purple-900/20 border border-purple-500/30 rounded-lg p-6 hover:border-purple-500/60 transition text-center">
              <div className="text-4xl mb-4">𝕏</div>
              <h3 className="font-bold mb-2">Twitter</h3>
              <p className="text-gray-400 text-sm">Follow for updates</p>
            </a>
            <a href="#" className="bg-purple-900/20 border border-purple-500/30 rounded-lg p-6 hover:border-purple-500/60 transition text-center">
              <div className="text-4xl mb-4">📱</div>
              <h3 className="font-bold mb-2">Telegram</h3>
              <p className="text-gray-400 text-sm">Chat with us</p>
            </a>
            <a href="#" className="bg-purple-900/20 border border-purple-500/30 rounded-lg p-6 hover:border-purple-500/60 transition text-center">
              <div className="text-4xl mb-4">🌐</div>
              <h3 className="font-bold mb-2">Website</h3>
              <p className="text-gray-400 text-sm">Learn more</p>
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-purple-500/20 py-12 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <img src={APP_LOGO} alt="ANON" className="w-8 h-8 rounded" />
                <span className="font-bold text-purple-400">$ANON</span>
              </div>
              <p className="text-gray-400 text-sm">The memecoin that values privacy and community.</p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#about" className="hover:text-purple-400 transition">About</a></li>
                <li><a href="#how-to-buy" className="hover:text-purple-400 transition">How to Buy</a></li>
                <li><a href="#tokenomics" className="hover:text-purple-400 transition">Tokenomics</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Resources</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#" className="hover:text-purple-400 transition">Whitepaper</a></li>
                <li><a href="#" className="hover:text-purple-400 transition">Documentation</a></li>
                <li><a href="#" className="hover:text-purple-400 transition">FAQ</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Contract</h4>
              <p className="text-gray-400 text-sm break-all">{contractAddress}</p>
            </div>
          </div>
          <div className="border-t border-purple-500/20 pt-8 text-center text-gray-400 text-sm">
            <p>© 2025 $ANON. All rights reserved. Stay Anonymous.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
